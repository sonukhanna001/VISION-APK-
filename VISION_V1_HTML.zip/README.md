# VISION ⚜️
A mobile-first HTML voice-assistant prototype.

V1 includes Jarvis-style UI, microphone input, speech output, and command text input. Android app control requires a native Android layer later.
